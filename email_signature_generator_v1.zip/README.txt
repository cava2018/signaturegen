To generate an email signature:
1. double click on "index.html" file
2. fillout the form
3. click "Build My Signature" button
4. double-click on "code.html" file to review your signature in web-browser
5. To add you signature in Outlook:
a) copy/paste output from Step 4    OR
b) follow help link displayed from Step 1